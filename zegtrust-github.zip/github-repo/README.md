# ZEG Publishing & H3 in Motion

**Empowering Authors. Enchanting Readers. Hands Helping Hands.**

A ministry-rooted nonprofit ecosystem based in Winston-Salem, NC — uniting publishing, wellness education, literacy, barbering, cosmetology, and community service.

---

## 🌐 Live Site

Deploy to GitHub Pages and connect your custom domain: `zegtrust.org`

---

## 📁 File Structure

```
/
├── index.html              ← Main website (ZEG Publishing + H3 in Motion)
├── css/
│   └── style.css           ← All styles
├── js/
│   └── main.js             ← Book management + interactions
├── images/
│   ├── zeg-logo.jpg        ← ZEG Publishing logo (gold)
│   ├── zeg-black.jpg       ← ZEG Publishing logo (black)
│   ├── h3-logo.png         ← H3 in Motion logo
│   ├── diwan-seal.png      ← Diwan El-Mahrifah emblem
│   └── book-*.png/jpg      ← Book cover images
└── academy/
    └── index.html          ← Wellness Academy student portal
```

---

## 📚 Adding Books

Click **"+ Add Book"** on the Catalog section of the live site. You can:
- Upload a cover image (JPG/PNG, up to 5MB)
- Add title, author, genre, description
- Add Amazon, Barnes & Noble, and Ingram Sparks links
- Set a book as the featured title on the homepage

Books are saved in your browser's local storage — they persist between visits.

---

## 🚀 Deploy to GitHub Pages

1. Create a GitHub account at [github.com](https://github.com)
2. Create a new **public** repository named `zegtrust`
3. Upload all files, keeping the folder structure intact
4. Go to **Settings → Pages → Source: main branch, root folder → Save**
5. Site goes live at `https://yourusername.github.io/zegtrust`

### Connect your domain (zegtrust.org)
1. In GitHub Pages settings → **Custom domain** → type `zegtrust.org` → Save
2. In your domain registrar's DNS settings, add:
```
A     @     185.199.108.153
A     @     185.199.109.153
A     @     185.199.110.153
A     @     185.199.111.153
```

---

## ✉️ Contact

- **H3 in Motion:** h3inmotion@gmail.com
- **ZEG Publishing:** information.zeg1@gmail.com  
- **Phone:** 803-651-4011 · 336-447-3887
- **Address:** 648 Hanes Mall Blvd, Suite 124, Winston-Salem, NC 27103

---

© 2026 ZEG Publishing, LLC · H3 in Motion · All Rights Reserved  
Diwan El-Ma'rifah Wellness Academy · 508(c)(1)(A) Ministry
