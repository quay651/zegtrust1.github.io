/* ============================================
   ZEG PUBLISHING & H3 IN MOTION
   Main JavaScript
   ============================================ */

'use strict';

/* ─── BOOK DATA STORE ─────────────────────────────────── */
const DEFAULT_BOOKS = [
  {
    id: 'book-001',
    title: "My First Haircut",
    author: "Huni Ali",
    genre: "Children's Books",
    description: "A warm, illustrated children's story celebrating a first big milestone. A joyful read for families everywhere — now available in print and e-book worldwide.",
    coverUrl: "images/book-my-first-haircut.png",
    amazonUrl: "#",
    bnUrl: "#",
    ingramUrl: "#",
    featured: true
  },
  {
    id: 'book-002',
    title: "Marigold's Sovereign's Scepter",
    author: "ZEG Publishing",
    genre: "Adventure / Fantasy",
    description: "An imaginative tale of courage beneath the waves — illustrated and ready for young adventurers everywhere.",
    coverUrl: "",
    coverGradient: "linear-gradient(135deg,#1a0d2e,#2d1a4e)",
    amazonUrl: "#",
    bnUrl: "#",
    featured: false
  }
];

let books = loadBooks();

function loadBooks() {
  try {
    const stored = localStorage.getItem('zeg_books');
    return stored ? JSON.parse(stored) : [...DEFAULT_BOOKS];
  } catch { return [...DEFAULT_BOOKS]; }
}

function saveBooks() {
  try { localStorage.setItem('zeg_books', JSON.stringify(books)); } catch {}
}

function generateId() {
  return 'book-' + Date.now() + '-' + Math.random().toString(36).substr(2,6);
}

/* ─── NAV ─────────────────────────────────────────────── */
function initNav() {
  const nav = document.getElementById('nav');
  const hamburger = document.getElementById('hamburger');
  const drawer = document.getElementById('nav-drawer');

  // Scroll shrink
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });

  // Hamburger
  window.toggleNav = function() {
    hamburger.classList.toggle('open');
    drawer.classList.toggle('open');
    document.body.style.overflow = drawer.classList.contains('open') ? 'hidden' : '';
  };
  window.closeNav = function() {
    hamburger.classList.remove('open');
    drawer.classList.remove('open');
    document.body.style.overflow = '';
  };

  // Close on outside click
  document.addEventListener('click', e => {
    if (drawer.classList.contains('open') && !nav.contains(e.target)) closeNav();
  });
}

/* ─── SCROLL REVEAL ───────────────────────────────────── */
function initReveal() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}

/* ─── BOOK RENDERING ──────────────────────────────────── */
function renderFeaturedBook() {
  const featured = books.find(b => b.featured) || books[0];
  if (!featured) return;

  const el = document.getElementById('featured-book');
  if (!el) return;

  const coverHtml = featured.coverUrl
    ? `<img src="${featured.coverUrl}" alt="${featured.title}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
    : '';
  const placeholderStyle = featured.coverGradient ? `style="background:${featured.coverGradient}"` : '';

  el.innerHTML = `
    <div class="book-cover-lg">
      ${coverHtml}
      <div class="book-cover-placeholder" ${placeholderStyle} ${featured.coverUrl ? 'style="display:none"' : ''}>${featured.title}</div>
    </div>
    <div class="book-info">
      <h3>${featured.title}</h3>
      <span class="book-author">${featured.author}</span>
      <p>${featured.description}</p>
      <div class="retailer-row">
        ${featured.amazonUrl ? `<a class="retailer-badge" href="${featured.amazonUrl}" target="_blank" rel="noopener">Amazon</a>` : ''}
        ${featured.bnUrl ? `<a class="retailer-badge" href="${featured.bnUrl}" target="_blank" rel="noopener">Barnes &amp; Noble</a>` : ''}
        ${featured.ingramUrl ? `<a class="retailer-badge" href="${featured.ingramUrl}" target="_blank" rel="noopener">Ingram Sparks</a>` : ''}
      </div>
      <a class="btn-buy" href="${featured.amazonUrl || '#'}" target="_blank" rel="noopener">
        <span>🛒</span> Buy Now
      </a>
    </div>
  `;
}

function renderSecondaryBooks() {
  const el = document.getElementById('secondary-books');
  if (!el) return;
  const secondary = books.filter(b => !b.featured).slice(0, 2);

  el.innerHTML = secondary.map(book => `
    <div class="book-mini-card">
      <div class="book-mini-cover">
        ${book.coverUrl
          ? `<img src="${book.coverUrl}" alt="${book.title}" onerror="this.parentElement.innerHTML='<div class=book-cover-placeholder>${book.title}</div>'">`
          : `<div class="book-cover-placeholder" ${book.coverGradient ? `style="background:${book.coverGradient}"` : ''}>${book.title}</div>`
        }
      </div>
      <div>
        <h4>${book.title}</h4>
        <span>${book.genre}</span>
      </div>
      <a class="btn-buy" href="${book.amazonUrl || '#'}" target="_blank" rel="noopener">
        <span>🛒</span> Buy Now
      </a>
    </div>
  `).join('');
}

function renderAllBooks(filter = 'all') {
  const grid = document.getElementById('books-grid');
  if (!grid) return;

  const filtered = filter === 'all' ? books : books.filter(b => b.genre === filter);

  const bookCards = filtered.map(book => `
    <div class="book-grid-card" data-id="${book.id}">
      <div class="book-grid-cover">
        ${book.coverUrl
          ? `<img src="${book.coverUrl}" alt="${book.title}" onerror="this.parentElement.innerHTML='<div class=book-cover-placeholder style=height:100%;background:${book.coverGradient||'var(--card2)'}>${book.title}</div>'">`
          : `<div class="book-cover-placeholder" style="height:100%;${book.coverGradient ? `background:${book.coverGradient}` : ''}">${book.title}</div>`
        }
      </div>
      <div class="book-grid-body">
        <h3>${book.title}</h3>
        <span class="book-author">${book.author}</span>
        <span class="book-genre">${book.genre}</span>
        <p>${book.description}</p>
        <div class="book-grid-actions">
          <a class="btn-buy" href="${book.amazonUrl || '#'}" target="_blank" rel="noopener"><span>🛒</span> Buy Now</a>
          <button class="btn btn-outline" onclick="openEditModal('${book.id}')">Edit</button>
        </div>
      </div>
    </div>
  `).join('');

  grid.innerHTML = bookCards + `
    <button class="add-book-btn" onclick="openAddModal()">
      <span class="add-icon">＋</span>
      <span>Add New Book</span>
    </button>
  `;

  // Trigger reveal on new cards
  grid.querySelectorAll('.book-grid-card').forEach((el, i) => {
    el.classList.add('reveal');
    setTimeout(() => el.classList.add('visible'), i * 80);
  });
}

/* ─── FILTER ──────────────────────────────────────────── */
function initFilters() {
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderAllBooks(btn.dataset.filter);
    });
  });
}

/* ─── BOOK MODAL ──────────────────────────────────────── */
let editingId = null;
let uploadedImageData = null;

window.openAddModal = function() {
  editingId = null;
  uploadedImageData = null;
  document.getElementById('modal-title').textContent = 'Add New Book';
  document.getElementById('book-form').reset();
  document.getElementById('img-preview').style.display = 'none';
  document.getElementById('delete-btn').style.display = 'none';
  document.getElementById('book-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
};

window.openEditModal = function(id) {
  const book = books.find(b => b.id === id);
  if (!book) return;
  editingId = id;
  uploadedImageData = null;

  document.getElementById('modal-title').textContent = 'Edit Book';
  document.getElementById('book-title').value = book.title || '';
  document.getElementById('book-author').value = book.author || '';
  document.getElementById('book-genre').value = book.genre || '';
  document.getElementById('book-desc').value = book.description || '';
  document.getElementById('book-amazon').value = book.amazonUrl || '';
  document.getElementById('book-bn').value = book.bnUrl || '';
  document.getElementById('book-ingram').value = book.ingramUrl || '';
  document.getElementById('book-featured').checked = book.featured || false;

  const preview = document.getElementById('img-preview');
  if (book.coverUrl) { preview.src = book.coverUrl; preview.style.display = 'block'; }
  else { preview.style.display = 'none'; }

  document.getElementById('delete-btn').style.display = 'inline-flex';
  document.getElementById('book-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
};

window.closeModal = function() {
  document.getElementById('book-modal').classList.remove('open');
  document.body.style.overflow = '';
  editingId = null;
  uploadedImageData = null;
};

window.saveBook = function() {
  const title = document.getElementById('book-title').value.trim();
  const author = document.getElementById('book-author').value.trim();
  if (!title || !author) { showToast('⚠️ Title and author are required.'); return; }

  const isFeatured = document.getElementById('book-featured').checked;

  // If this book is being set as featured, unset others
  if (isFeatured) books.forEach(b => { b.featured = false; });

  const bookData = {
    title,
    author,
    genre: document.getElementById('book-genre').value || "General",
    description: document.getElementById('book-desc').value.trim() || '',
    amazonUrl: document.getElementById('book-amazon').value.trim() || '#',
    bnUrl: document.getElementById('book-bn').value.trim() || '',
    ingramUrl: document.getElementById('book-ingram').value.trim() || '',
    featured: isFeatured,
    coverUrl: uploadedImageData || '',
  };

  if (editingId) {
    const idx = books.findIndex(b => b.id === editingId);
    if (idx !== -1) books[idx] = { ...books[idx], ...bookData };
    showToast('✅ Book updated successfully.');
  } else {
    books.push({ id: generateId(), ...bookData });
    showToast('✅ Book added successfully.');
  }

  saveBooks();
  closeModal();
  renderFeaturedBook();
  renderSecondaryBooks();
  renderAllBooks(document.querySelector('.filter-btn.active')?.dataset.filter || 'all');
};

window.deleteBook = function() {
  if (!editingId) return;
  if (!confirm('Remove this book from the site?')) return;
  books = books.filter(b => b.id !== editingId);
  if (books.length && !books.find(b => b.featured)) books[0].featured = true;
  saveBooks();
  closeModal();
  renderFeaturedBook();
  renderSecondaryBooks();
  renderAllBooks(document.querySelector('.filter-btn.active')?.dataset.filter || 'all');
  showToast('🗑 Book removed.');
};

/* ─── IMAGE UPLOAD ────────────────────────────────────── */
function initImageUpload() {
  const input = document.getElementById('book-cover-input');
  const preview = document.getElementById('img-preview');
  if (!input) return;

  input.addEventListener('change', () => {
    const file = input.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { showToast('⚠️ Image must be under 5MB.'); return; }

    const reader = new FileReader();
    reader.onload = e => {
      uploadedImageData = e.target.result;
      preview.src = uploadedImageData;
      preview.style.display = 'block';
    };
    reader.readAsDataURL(file);
  });
}

/* ─── CONTACT FORM ────────────────────────────────────── */
function initContactForm() {
  const btn = document.getElementById('contact-submit');
  if (!btn) return;

  btn.addEventListener('click', () => {
    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const interest = document.getElementById('contact-interest').value;
    const msg = document.getElementById('contact-msg').value.trim();

    if (!name || !email) {
      showToast('⚠️ Please fill in your name and email.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showToast('⚠️ Please enter a valid email address.');
      return;
    }

    const subject = encodeURIComponent(`${interest} — Inquiry from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nInterest: ${interest}\n\n${msg}`);
    window.location.href = `mailto:h3inmotion@gmail.com?subject=${subject}&body=${body}`;

    btn.innerHTML = '<span>✅</span> Opening your email...';
    btn.style.background = '#2d7a4f';
    setTimeout(() => {
      btn.innerHTML = '<span>✉️</span> Send Message';
      btn.style.background = '';
    }, 3500);
  });
}

/* ─── TOAST ───────────────────────────────────────────── */
function showToast(msg) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3200);
}

/* ─── MODAL OUTSIDE CLICK ─────────────────────────────── */
function initModalClose() {
  const overlay = document.getElementById('book-modal');
  if (!overlay) return;
  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeModal();
  });
}

/* ─── KEYBOARD ────────────────────────────────────────── */
function initKeyboard() {
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      closeModal();
      closeNav();
    }
  });
}

/* ─── INIT ────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initReveal();
  renderFeaturedBook();
  renderSecondaryBooks();
  renderAllBooks();
  initFilters();
  initImageUpload();
  initContactForm();
  initModalClose();
  initKeyboard();
});
